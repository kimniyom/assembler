<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Users;
use yii\data\ArrayDataProvider;

class UserController extends Controller {

    public function actionIndex() {
        $use = new Users();
        $user = $use->GetUserAll();

        $provider = new ArrayDataProvider([
            'allModels' => $user,
            'pagination' => [
                'pageSize' => 2,
            ],
            'sort' => [
                'attributes' => ['id','name'],
            ],
        ]);
        
        $data['provider'] = $provider;
        
        return $this->render('index',$data);
        
    }

}
