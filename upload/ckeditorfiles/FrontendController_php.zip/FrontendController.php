<?php

namespace app\controllers;

use yii\web\Controller;

class FrontendController extends Controller {

    public $layout = "main";

    public function actionIndex() {
        return $this->render('index');
    }

    public function actionTheme2() {
        $this->layout = "frontend";
        return $this->render('theme2');
    }

}
