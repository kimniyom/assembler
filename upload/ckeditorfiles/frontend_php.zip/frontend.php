<?php
/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use app\assets\FrontendAsset;
use yii\helpers\Url;

AppAsset::register($this);
FrontendAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?= Html::csrfMetaTags() ?>
        <title><?= Html::encode($this->title) ?></title>
        <?php $this->head() ?>
    </head>
    <body>
        <?php $this->beginBody() ?>

        <nav class="navbar navbar-default">

        </nav>
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Kimniyom</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="#">ลิงค์ 1 <span class="sr-only">(current)</span></a></li>
                        <li><a href="#">ลิงค์ 2 </a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">ลิงค์ 3 Dropdown <span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Action</a></li>
                                <li><a href="#">Another action</a></li>
                                <li><a href="#">Something else here</a></li>
                                <li class="divider"></li>
                                <li><a href="#">Separated link</a></li>
                                <li class="divider"></li>
                                <li><a href="#">One more separated link</a></li>
                            </ul>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">Link</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class=" container-fluid">
            <!-- ส่วน body -->
            <div class="row">
                <!-- เมนู -->
                <div class="col-lg-3 col-md-3 col-sm-12">
                    <div class="list-group">
                        <a href="#" class="list-group-item active">
                            <span class="glyphicon glyphicon-object-align-left"></span> เมนูเว็บไซต์
                        </a>
                        <a href="#" class="list-group-item">
                            Dapibus ac facilisis in
                        </a>
                        <a href="#" class="list-group-item">
                            Morbi leo risus
                        </a>
                        <a href="#" class="list-group-item">
                            Morbi leo risus
                        </a>
                        <a href="#" class="list-group-item">
                            Morbi leo risus
                        </a>
                    </div>
                </div>

                <!-- ส่วนแสดงผล -->
                <div class="col-lg-9 col-md-9 col-sm-12">
                    <?=
                    Breadcrumbs::widget([
                        'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
                    ])
                    ?>

                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                <i class="fa fa-user"></i>
                                ส่วนแสดงผล
                            </h3>
                        </div>
                        <div class="panel-body" style="background: #FFF; color: #000;">
                            <?= $content ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        
        <nav class="navbar navbar-default navbar-fixed-bottom">
            <div class=" container-fluid" style=" padding-top: 20px;">ชิดล่าง</div>
        </nav>




        <?php $this->endBody() ?>
    </body>
</html>
<?php $this->endPage() ?>
