<?php

use yii\grid\GridView;
use yii\helpers\Html;

echo GridView::widget([
    'dataProvider' => $provider,
    'columns' => [
        ['class' => 'yii\grid\SerialColumn'],
        'id',
        [
            'attribute' => 'username',
            'label' => 'ชื่อเข้าใช้งาน',
            'contentOptions' => ['style' => 'color:red;'],
        ],
        [
            'attribute' => 'password',
            'label' => 'รหัสผ่าน'
        ],
        [
            'attribute' => 'name',
            'label' => 'ชื่อ'
        ],
        [
            'attribute' => 'lname',
            'label' => 'นามสกุล'
        ],
        [
            'label' => 'สถานะ',
            //'format' => 'raw',
            'value' => function($data) {
                $use_type = $data['status'];
                if ($use_type == 'A') {
                    $status = "ผู้ดูแลระบบ";
                } else {
                    $status = "ทั่วไป";
                }
                return $status;
            }
        ],
        [
            'label' => 'จัดการ',
            'format' => 'raw',
            'value' => function($data) {
                $id = $data['id'];
                $btn_edit = "<div class='btn btn-success' onclick=\"Edit('$id')\">แก้ไข</div>";
                $btn_delete = "<div class='btn btn-danger' onclick=\"Delete('$id')\">ลบ</div>";
                return Html::a($btn_edit . ' ' . $btn_delete, '#');
            }
        ],
    // 'isactive',
    ],
    'tableOptions' => ['class' => 'table table-striped table-bordered'],
]);
?>

<script type="text/javascript">
    function Edit(id) {
        alert('จะแก้ไขหรอ' + id);
    }

    function Delete(id) {
        alert('จะลบใช่ไหม' + id);
    }
</script>

